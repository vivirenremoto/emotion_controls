

var eastwood_url = 'https://vivirenremoto.github.io/eastwood_gmail/';

function confirm_delete(e) {

    if (e.origin.indexOf('vivirenremoto.github.io') > -1) {


        console.log(e.data);




        var action_button;


        if (document.location.host.indexOf('mail.google.com') > -1) {
            if (e.data == 'angry') {
                deleteMail();
            }

        } else if (document.location.host.indexOf('youtube.com') > -1) {

            if (e.data == 'happy') {
                action_button = document.querySelector('#top-level-buttons > ytd-toggle-button-renderer:nth-child(1) > a > #button.style-text');
                action_button.click();

            } else if (e.data == 'angry') {
                action_button = document.querySelector('#related .ytd-thumbnail');//document.querySelector('#top-level-buttons > ytd-toggle-button-renderer:nth-child(2) > a > #button');
                action_button.click();
            }


        } else if (document.location.host.indexOf('open.spotify.com') > -1) {


            if (e.data == 'happy') {

                action_button = document.querySelectorAll('.spoticon-heart-16')[0];

                if (action_button.className.indexOf('active') == -1) {
                    action_button.click();
                }

            } else if (e.data == 'angry') {
                action_button = document.querySelector('.spoticon-skip-forward-16');
                action_button.click();
            }


        } else if (document.location.href.indexOf('www.producthunt.com/posts') > -1) {

            var action_button = document.querySelector('.voteButtonAside_1094f [data-test="vote-button"]');


            if (e.data == 'happy') {
                if (action_button.className.indexOf('active') == -1) {
                    action_button.click();
                }

            } else if (e.data == 'angry') {

                if (action_button.className.indexOf('active') > -1) {
                    action_button.click();
                }
            }



        } else if (document.location.href.indexOf('www.instagram.com/p/') > -1) {

            if (e.data == 'happy') {
                action_button = document.querySelector('.voteButtonAside_1094f .orangeSolidColor_1132c');

                if (document.querySelectorAll('article section button:nth-child(1) svg')[0].getAttribute('fill') == '#262626') {
                    action_button = document.querySelectorAll('article section button')[0];
                    action_button.click();
                }

            } else if (e.data == 'angry') {
                if (document.querySelectorAll('article section button:nth-child(1) svg')[0].getAttribute('fill') == '#ed4956') {
                    action_button = document.querySelectorAll('article section button')[0];
                    action_button.click();
                }
            }

        } else if (document.location.host.indexOf('www.facebook.com') > -1) {


            if (e.data == 'happy') {
                if (document.querySelectorAll('[aria-label="Like"]').length == 1) {

                    action_button = document.querySelector('[aria-label="Like"]');

                    action_button.click();

                }
            } else if (e.data == 'angry') {

                if (document.querySelectorAll('[aria-label="Remove Like"]').length == 1) {

                    action_button = document.querySelector('[aria-label="Remove Like"]');

                    action_button.click();

                }

            }


        } else if (document.location.host.indexOf('twitter.com') > -1 && document.location.href.indexOf('/status/') > -1) {


            if (e.data == 'happy') {

                action_button = document.querySelectorAll('article')[0].querySelectorAll('[data-testid="like"]')[0];
                if (action_button) {
                    action_button.click();
                }

            } else if (e.data == 'angry') {
                action_button = document.querySelectorAll('article')[0].querySelectorAll('[data-testid="unlike"]')[0];
                if (action_button) {
                    action_button.click();
                }
            }



        }







    }
}


function loadWebcam() {
    var eastwood = document.createElement("div");
    eastwood.innerHTML = '<div style="z-index:999999999999;position:fixed;bottom:0;right:0;background:#fff;"><iframe id="webcam" allow="camera;microphone" src="' + eastwood_url + '" style="background:#fff;border:0;width:320px;height:240px;"></iframe></div>';


    document.body.appendChild(eastwood);

    window.addEventListener('message', confirm_delete, false);


}



// https://chrome.google.com/webstore/detail/delete-key-for-gmail/alpohlaboohebmblbmanccbepncahbda


function triggerMostButtons(jNode) {
    triggerMouseEvent(jNode, "mouseover");
    triggerMouseEvent(jNode, "mousedown");
    triggerMouseEvent(jNode, "mouseup");
    triggerMouseEvent(jNode, "click");
}

function triggerMouseEvent(node, eventType) {
    var clickEvent = document.createEvent('MouseEvents');
    clickEvent.initEvent(eventType, true, true);
    node.dispatchEvent(clickEvent);
}

function deleteMail() {

    var btn_delete = document.querySelectorAll('.ar9');


    triggerMostButtons(btn_delete[btn_delete.length - 1]);

}

loadWebcam();


