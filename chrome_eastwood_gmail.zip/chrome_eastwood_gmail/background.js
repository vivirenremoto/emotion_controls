

var eastwood_url = 'https://vivirenremoto.github.io/eastwood_gmail/';

function confirm_delete(e) {

    if (e.origin.indexOf('vivirenremoto.github.io') > -1) {

        deleteMail();

        document.getElementById('eastwood').style.display = 'block';
        document.getElementById('webcam').style.display = 'none';

        setTimeout(function () {
            document.getElementById('eastwood').style.display = 'none';
            document.getElementById('webcam').style.display = 'block';
        }, 3000);

    }
}


function loadWebcam() {
    var eastwood = document.createElement("div");
    eastwood.innerHTML = '<div style="z-index:99;position:fixed;bottom:0;right:0;"><img src="https://vivirenremoto.github.io/eastwood_gmail/eastwood.png" style="display:none" id="eastwood"><iframe id="webcam" allow="camera;microphone" src="' + eastwood_url + '" style="background:#fff;border:0;width:320px;height:240px;"></iframe></div>';


    document.body.appendChild(eastwood);

    window.addEventListener('message', confirm_delete, false);


}



// https://chrome.google.com/webstore/detail/delete-key-for-gmail/alpohlaboohebmblbmanccbepncahbda


function triggerMostButtons(jNode) {
    triggerMouseEvent(jNode, "mouseover");
    triggerMouseEvent(jNode, "mousedown");
    triggerMouseEvent(jNode, "mouseup");
    triggerMouseEvent(jNode, "click");
}

function triggerMouseEvent(node, eventType) {
    var clickEvent = document.createEvent('MouseEvents');
    clickEvent.initEvent(eventType, true, true);
    node.dispatchEvent(clickEvent);
}

function deleteMail() {
    // Find out what element is currently in focus
    try {
        var focusedElement = document.activeElement;
        if (focusedElement.getAttribute('contenteditable') || focusedElement.tagName === "INPUT" || focusedElement.tagName === "TEXTAREA") {
            // Don't delete the email if the user is using an input element or an editable element (aka typing an email or doing a search)
            return
        }
    } catch (err) {
        console.log("Error finding focused element: " + err)
    }

    var more_button = document.querySelector('div[data-message-id] div[data-tooltip="More"]');
    if (more_button === null) {
        more_button = document.querySelector('div[data-message-id] div[data-tooltip="Más"]');
    }

    if (more_button) {

        // Simulate click on dropdown menu
        triggerMostButtons(document.querySelector('div[data-message-id] div[data-tooltip="Más"]'));
        // Simulate click on 'Delete this message' menu item
        var deleteMenuItem = document.querySelector('div[class="b7 J-M"] #tm');
        // This needs to be triggered twice for some reason
        triggerMostButtons(deleteMenuItem);
        triggerMostButtons(deleteMenuItem);
        // Restore focus to original element
        try {
            focusedElement.focus();
        } catch (err) {
            console.log("Error restoring element focus: " + err)
        }
    }


}

loadWebcam();


