chrome.browserAction.onClicked.addListener(function () {
    chrome.tabs.create({ 'url': 'https://dev.to/vivirenremoto/emotion-controls-for-the-web-3ja3' });
});

