

var emotions_url = 'https://vivirenremoto.github.io/emotion_controls/';

function confirm_action(e) {

    if (e.origin.indexOf('vivirenremoto.github.io') > -1) {


        //console.log(e.data);


        var action_button;


        if (document.location.host.indexOf('mail.google.com') > -1) {
            if (e.data == 'angry') {
                deleteMail();
            }

        } else if (document.location.host.indexOf('youtube.com') > -1) {

            if (e.data == 'happy') {
                action_button = document.querySelector('#top-level-buttons > ytd-toggle-button-renderer:nth-child(1) > a > #button.style-text');
                action_button.click();

            } else if (e.data == 'angry') {
                action_button = document.querySelector('#related .ytd-thumbnail');//document.querySelector('#top-level-buttons > ytd-toggle-button-renderer:nth-child(2) > a > #button');
                action_button.click();
            }


        } else if (document.location.host.indexOf('open.spotify.com') > -1) {


            if (e.data == 'happy') {

                action_button = document.querySelectorAll('.now-playing-bar .spoticon-heart-16')[0];

                if (action_button.className.indexOf('active') == -1) {
                    action_button.click();
                }

            } else if (e.data == 'angry') {
                action_button = document.querySelector('.now-playing-bar .spoticon-skip-forward-16');
                action_button.click();
            }


        } else if (document.location.href.indexOf('www.producthunt.com/posts') > -1) {

            var action_button = document.querySelector('.voteButtonAside_1094f [data-test="vote-button"]');


            if (e.data == 'happy') {
                if (action_button.className.indexOf('active') == -1) {
                    action_button.click();
                }

            } else if (e.data == 'angry') {

                if (action_button.className.indexOf('active') > -1) {
                    action_button.click();
                }
            }



        } else if (document.location.href.indexOf('www.instagram.com/p/') > -1) {

            if (e.data == 'happy') {
                action_button = document.querySelector('.voteButtonAside_1094f .orangeSolidColor_1132c');

                if (document.querySelectorAll('article section button:nth-child(1) svg')[0].getAttribute('fill') == '#262626') {
                    action_button = document.querySelectorAll('article section button')[0];
                    action_button.click();
                }

            } else if (e.data == 'angry') {
                if (document.querySelectorAll('article section button:nth-child(1) svg')[0].getAttribute('fill') == '#ed4956') {
                    action_button = document.querySelectorAll('article section button')[0];
                    action_button.click();
                }
            }

        } else if (document.location.host.indexOf('www.facebook.com') > -1) {


            if (e.data == 'happy') {


                action_button = document.querySelectorAll('div[role=complementary] [aria-label="Like"]')[0];

                if( !action_button ){
                    action_button = document.querySelectorAll('[data-testid="Keycommand_wrapper_feed_story"] [aria-label="Like"]')[0];
                }

                if (action_button) {

                    action_button.click();

                }
            } else if (e.data == 'angry') {

                action_button = document.querySelectorAll('div[role=complementary] [aria-label="Remove Like"]')[0];

                if( !action_button ){
                    action_button = document.querySelectorAll('[data-testid="Keycommand_wrapper_feed_story"] [aria-label="Remove Like"]')[0];
                }
                
                if (action_button) {

                    action_button.click();

                }

            }


        } else if (document.location.host.indexOf('twitter.com') > -1 && document.location.href.indexOf('/status/') > -1) {


            if (e.data == 'happy') {

                action_button = document.querySelectorAll('article')[0].querySelectorAll('[data-testid="like"]')[0];
                if (action_button) {
                    action_button.click();
                }

            } else if (e.data == 'angry') {
                action_button = document.querySelectorAll('article')[0].querySelectorAll('[data-testid="unlike"]')[0];
                if (action_button) {
                    action_button.click();
                }
            }



        } else if (document.location.host.indexOf('linkedin.com') > -1 && document.location.href.indexOf('/mynetwork/') > -1) {

            if (document.querySelectorAll('.invitation-card__action-container').length > 0) {

                if (e.data == 'happy') {

                    action_button = document.querySelector('.invitation-card__action-btn:nth-child(2)');
                    if (action_button) {
                        action_button.click();
                    }

                } else if (e.data == 'angry') {
                    action_button = document.querySelector('.invitation-card__action-btn:nth-child(1)');
                    if (action_button) {
                        action_button.click();
                    }

                }

            }



        }







    }
}


function loadWebcam() {
    var cam = document.createElement("div");
    cam.innerHTML = '<div style="border:2px black solid;border-right:0;border-bottom:0;z-index:999999999999;position:fixed;bottom:0;right:0;background:black;"><iframe id="webcam" allow="camera;microphone" src="' + emotions_url + '" style="background:black;border:0;width:320px;height:240px;"></iframe></div>';


    document.body.appendChild(cam);

    window.addEventListener('message', confirm_action, false);


}


// javascript code to the delete the current email on gmail
// https://chrome.google.com/webstore/detail/delete-key-for-gmail/alpohlaboohebmblbmanccbepncahbda


function triggerMostButtons(jNode) {
    triggerMouseEvent(jNode, "mouseover");
    triggerMouseEvent(jNode, "mousedown");
    triggerMouseEvent(jNode, "mouseup");
    triggerMouseEvent(jNode, "click");
}

function triggerMouseEvent(node, eventType) {
    var clickEvent = document.createEvent('MouseEvents');
    clickEvent.initEvent(eventType, true, true);
    node.dispatchEvent(clickEvent);
}

function deleteMail() {

    var btn_delete = document.querySelectorAll('.ar9');


    triggerMostButtons(btn_delete[btn_delete.length - 1]);

}

loadWebcam();


